promises 1.0
================

- Initial CRAN release
